/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.manueltangcay.manueltangcay;

/**
 *
 * 
 */


import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.swing.ImageIcon;
import java.awt.MediaTracker;
import javax.sound.sampled.*;
import java.net.URL;
import java.io.*;
import javax.swing.JOptionPane;

public class Form extends javax.swing.JFrame {
    
    //Initializing Strings
    String[] biodegradable = new String[5];
    
    String[] nonBiodegradable = new String[5];
    
    String[] recyclable = new String[5];
    
    String[] trashArr = new String[15];
    
    //the order in which the trash items will appear
    int[] rearrangedIndex = {0,11,7,8,4,10,6,2,13,9,14,1,12,5,3};
    
    //Initializing count
    int count = 0;
    
    
    public Form() {
        
        // constructor sets the UI and the filepath
        initComponents();
        Manueltangcay.getImageFilePath();
        playAudio(Manueltangcay.programAudio);
        
        bin1Btn.setVisible(false);
        bin2Btn.setVisible(false);
        bin3Btn.setVisible(false);
        displayTrash.setVisible(false);
        bin1Name.setVisible(false);
        bin2Name.setVisible(false);
        bin3Name.setVisible(false);
        /*
                
    
    };
        
        */
    }
    
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Label1 = new javax.swing.JLabel();
        label2 = new javax.swing.JLabel();
        startBtn = new javax.swing.JButton();
        bin3Btn = new javax.swing.JButton();
        bin1Btn = new javax.swing.JButton();
        bin2Btn = new javax.swing.JButton();
        trashDisplay = new javax.swing.JLabel();
        displayTrash = new javax.swing.JLabel();
        bin1Name = new javax.swing.JLabel();
        bin2Name = new javax.swing.JLabel();
        bin3Name = new javax.swing.JLabel();
        labelName1 = new javax.swing.JLabel();
        contactNum1 = new javax.swing.JLabel();
        email1 = new javax.swing.JLabel();
        labelName2 = new javax.swing.JLabel();
        contactNum2 = new javax.swing.JLabel();
        email2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Label1.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        Label1.setText("Sorting Game");

        label2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        label2.setText("Click the correct bin to throw the garbage item !!!");

        startBtn.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        startBtn.setText("START");
        startBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                startBtnActionPerformed(evt);
            }
        });

        bin3Btn.setText("jButton1");
        bin3Btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bin3BtnActionPerformed(evt);
            }
        });

        bin1Btn.setText("jButton1");
        bin1Btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bin1BtnActionPerformed(evt);
            }
        });

        bin2Btn.setText("jButton1");
        bin2Btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bin2BtnActionPerformed(evt);
            }
        });

        displayTrash.setText("jLabel2");

        bin1Name.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        bin1Name.setText("Non-Biodegradable");

        bin2Name.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        bin2Name.setText("Biodegradable");

        bin3Name.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        bin3Name.setText("Recyclable");

        labelName1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        labelName1.setText("Meynard Roi C, Manuel ");

        contactNum1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        contactNum1.setText("+639989700902");

        email1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        email1.setText("meynardmanuel69@gmail.com");

        labelName2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        labelName2.setText("Aara Angelique P. Tangcay");

        contactNum2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        contactNum2.setText("09156875303 ");

        email2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        email2.setText("aaraangelique@gmail.com");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(Label1, javax.swing.GroupLayout.PREFERRED_SIZE, 261, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(label2, javax.swing.GroupLayout.PREFERRED_SIZE, 446, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(startBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(labelName1)
                            .addComponent(contactNum1)
                            .addComponent(email1)
                            .addComponent(labelName2)
                            .addComponent(contactNum2)
                            .addComponent(email2))
                        .addGap(803, 803, 803)
                        .addComponent(trashDisplay)))
                .addContainerGap(69, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(bin1Btn, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(bin1Name, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(411, 411, 411)
                                .addComponent(bin3Btn, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGap(144, 144, 144)
                                .addComponent(bin2Name)
                                .addGap(210, 210, 210)
                                .addComponent(bin3Name, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(displayTrash, javax.swing.GroupLayout.PREFERRED_SIZE, 303, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(bin2Btn, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(129, 129, 129)))
                .addGap(181, 181, 181))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(Label1, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(label2, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(startBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(trashDisplay))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addComponent(labelName1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(contactNum1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(email1)
                        .addGap(28, 28, 28)
                        .addComponent(labelName2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(contactNum2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(email2))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(displayTrash, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(71, 71, 71)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(bin2Btn, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(bin3Btn, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(bin1Btn, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bin1Name, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bin2Name, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bin3Name, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(164, 164, 164))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    //method called to run the background audio
    private void playAudio(String location){
       try{
           File musicPath = new File(location);
           if(musicPath.exists()){
              AudioInputStream audioInput = AudioSystem.getAudioInputStream(musicPath);
              Clip clip = AudioSystem.getClip();
              clip.open(audioInput);
              clip.start();
           }else{
               
           }
           
           
       } catch(Exception e){
          System.out.println(e);  
        }
    };
    
    // runs when you click start button
    private void startBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_startBtnActionPerformed
        // TODO add your handling code here:
        // gets filepath
        Manueltangcay.getImageFilePath();

        // assigns all the png into their respective array
        biodegradable[0] = Manueltangcay.gBio + File.separator + "1" + ".png";
        biodegradable[1] = Manueltangcay.gBio + File.separator + "2" + ".png";
        biodegradable[2] = Manueltangcay.gBio + File.separator + "3" + ".png";
        biodegradable[3] = Manueltangcay.gBio + File.separator + "4" + ".png";
        biodegradable[4] = Manueltangcay.gBio + File.separator + "5" + ".png";
        
        nonBiodegradable[0] = Manueltangcay.gNonBio + File.separator + "1" + ".png";
        nonBiodegradable[1] = Manueltangcay.gNonBio + File.separator + "2" + ".png";
        nonBiodegradable[2] = Manueltangcay.gNonBio + File.separator + "3" + ".png";
        nonBiodegradable[3] = Manueltangcay.gNonBio + File.separator + "4" + ".png";
        nonBiodegradable[4] = Manueltangcay.gNonBio + File.separator + "5" + ".png";
        
        recyclable[0] = Manueltangcay.gRecyc + File.separator + "1" + ".png";
        recyclable[1] = Manueltangcay.gRecyc + File.separator + "2" + ".png";
        recyclable[2] = Manueltangcay.gRecyc + File.separator + "3" + ".png";
        recyclable[3] = Manueltangcay.gRecyc + File.separator + "4" + ".png";
        recyclable[4] = Manueltangcay.gRecyc + File.separator + "5" + ".png";
        
        
        // compiles all the data from the array to a single array
        trashArr[0] = biodegradable[0];
        trashArr[1] = biodegradable[1]; 
        trashArr[2] = biodegradable[2];
        trashArr[3] = biodegradable[3];
        trashArr[4] = biodegradable[4];
        trashArr[5] = nonBiodegradable[0];
        trashArr[6] = nonBiodegradable[1];
        trashArr[7] = nonBiodegradable[2];
        trashArr[8] = nonBiodegradable[3];
        trashArr[9] = nonBiodegradable[4];
        trashArr[10] = recyclable[0];
        trashArr[11] = recyclable[1];
        trashArr[12] = recyclable[2];
        trashArr[13] = recyclable[3];
        trashArr[14] = recyclable[4]; 
        
        label2.setVisible(false);
        startBtn.setVisible(false);
        
        startGame();
    }//GEN-LAST:event_startBtnActionPerformed

    private void bin3BtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bin3BtnActionPerformed
        // TODO add your handling code here:
        checkAnswer("recyclable");
    }//GEN-LAST:event_bin3BtnActionPerformed

    private void bin1BtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bin1BtnActionPerformed
        // TODO add your handling code here:
        checkAnswer("nonBiodegradable");
    }//GEN-LAST:event_bin1BtnActionPerformed

    private void bin2BtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bin2BtnActionPerformed
        // TODO add your handling code here:
        checkAnswer("biodegradable");
    }//GEN-LAST:event_bin2BtnActionPerformed
    private void getBinImages(){
        
        bin1Btn.setVisible(true);
        bin2Btn.setVisible(true);
        bin3Btn.setVisible(true);
        
        bin1Btn.setText("");
        bin2Btn.setText("");
        bin3Btn.setText("");
        
        Manueltangcay.getImageFilePath();
        String filepath = Manueltangcay.bins;
        ImageIcon binIcon1 = new ImageIcon(filepath + File.separator + "yellow.png");
        bin1Btn.setIcon(binIcon1);
        ImageIcon binIcon2 = new ImageIcon(filepath + File.separator + "green.png");
        bin2Btn.setIcon(binIcon2);
        ImageIcon binIcon3 = new ImageIcon(filepath + File.separator + "blue.png");
        bin3Btn.setIcon(binIcon3);
    }
    
    private void displayTrash(){
        //count keeps track of the trash items
        if(count < 15){
        
        //gets the icon filepath for the trash item
        String filepath = trashArr[rearrangedIndex[count]];
        ImageIcon icon = new ImageIcon(filepath);
        
        displayTrash.setVisible(true);
        displayTrash.setIcon(icon);
        displayTrash.setText("");
        
        
        } 
        else{
            // runs if the user has completed the game
            // will give the user a choice to play again or exit the program
            int choice = JOptionPane.showOptionDialog(
            null,
            "CONGRATS!!! Do you want to play again?",
            "CONGRATULATIONS ",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            new String[]{"Yes", "No, exit"},
            "Yes"
            );
            
            if(choice == 0){
                count = 0;
                displayTrash();
            } else{
                System.exit(0);
            }
        }
        
    }
    
    private void checkAnswer(String binType){
        String answer;
        // checks the answer using the integers inside rearrangesIndex
        // checks if the user's choice matches with the answer
        System.out.println(rearrangedIndex[count]);
        if(rearrangedIndex[count] < 5){
            answer = "biodegradable";
        } else if(rearrangedIndex[count] >= 5 && rearrangedIndex[count] <10){
            answer = "nonBiodegradable";
        } else{
            answer = "recyclable";
        }
        
        System.out.println("Anser: " + answer);
        
        if(binType.equals(answer)){
          System.out.println(binType + " correct");
          count++; 
          System.out.println(count);
          displayTrash();//displays the next icon if the user is correct
        } else{
            //shows message box if they are wrong
            wrongAnswerMessageBox("Try Again", "Wrong Answer");
            System.out.println(binType + " wrong");  
        }
    }
    
    //starts game and calls all the necessary functions
    private void startGame(){
        Manueltangcay.getImageFilePath();
        getBinImages();
        displayTrash();
        bin1Name.setVisible(true);
        bin2Name.setVisible(true);
        bin3Name.setVisible(true);
        labelName1.setVisible(false);
        contactNum1.setVisible(false);
        email1.setVisible(false);
        labelName2.setVisible(false);
        contactNum2.setVisible(false);
        email2.setVisible(false);
    }
    
    
    
    // the method that gets called when the user chooses the wrong choice
    private void wrongAnswerMessageBox(String msg, String titlebar){
        JOptionPane.showMessageDialog(null, msg, titlebar, JOptionPane.INFORMATION_MESSAGE);
    }
    
    
    
    
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Form.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Form.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Form.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Form.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                System.out.println();
                new Form().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Label1;
    private javax.swing.JButton bin1Btn;
    private javax.swing.JLabel bin1Name;
    private javax.swing.JButton bin2Btn;
    private javax.swing.JLabel bin2Name;
    private javax.swing.JButton bin3Btn;
    private javax.swing.JLabel bin3Name;
    private javax.swing.JLabel contactNum1;
    private javax.swing.JLabel contactNum2;
    private javax.swing.JLabel displayTrash;
    private javax.swing.JLabel email1;
    private javax.swing.JLabel email2;
    private javax.swing.JLabel label2;
    private javax.swing.JLabel labelName1;
    private javax.swing.JLabel labelName2;
    private javax.swing.JButton startBtn;
    private javax.swing.JLabel trashDisplay;
    // End of variables declaration//GEN-END:variables
}
