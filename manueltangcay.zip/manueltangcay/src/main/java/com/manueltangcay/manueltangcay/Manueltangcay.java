/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.manueltangcay.manueltangcay;

/**
 *
 * 
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Manueltangcay {
     //File path
    //saves all the file path in public variables
    public static String bins;
    public static String gBio;
    public static String gNonBio;
    public static String gRecyc;
    public static String programAudio;

    public static void getImageFilePath(){
            //gets the user filepath to the project
           String imagePath = System.getProperty("user.dir") + File.separator + "displayMaterials";
          
        
           bins = imagePath + File.separator + "binsImage";
           gBio = imagePath + File.separator + "garbageBio";
           gNonBio = imagePath + File.separator + "garbageNonBio";
           gRecyc = imagePath + File.separator + "garbageRecyc";
           programAudio = imagePath + File.separator + "programAudio.wav";

      
        
    }
    public static void main(String[] args) {
         getImageFilePath();
        System.out.println("Hello World!");
    }
}
